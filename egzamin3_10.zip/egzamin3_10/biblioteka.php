<html>
<head>
    <meta charset="UTF-8">
    <title>Biblioteka</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section id="baner">
        <h1>Biblioteka w Książkowicach Małych</h1>
    </section>
    <section id="lewy">
        <h4>Dodaj czytelnika</h4>
        <form method="POST">
        Imię: <input type="text" id="imie" name="imie"></input><br>
        Nazwisko: <input type="text" id="nazwisko" name="nazwisko"></input><br>
        Symbol: <input type="numeric" id="symbol" name="symbol"></input><br>
        <input type="SUBMIT" value="AKCEPTUJ"></input>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST"){
            $conn = new mysqli("localhost","root","","biblioteka",);

            $imie = $_POST['imie'];
            $nazwisko = $_POST['nazwisko'];
            $symbol = $_POST['symbol'];

            echo "Dodano użytkownika ".$imie." ".$nazwisko;
            mysqli_query($conn, "INSERT INTO czytelnicy (imie, nazwisko, kod) VALUES ('$imie', '$nazwisko', '$symbol')");

            mysqli_close($conn);
        }
        ?>
    </section>
    <section id="srodkowy">
        <img src="biblioteka.png" alt="biblioteka"></img>
        <h6>ul.<br> Czytelników&nbsp15; Książkowice Małe</h6>
        <a href="biuro@bib.pl"><p>Czy masz jakieś uwagi?</p><a>
    </section>
    <section id="prawy">
        <h4>Nasi czytelnicy:</h4>
        <?php
            $conn = new mysqli("localhost","root","","biblioteka",);

            $zap = mysqli_query($conn, "SELECT imie, nazwisko FROM czytelnicy ORDER BY nazwisko");

            echo "<ol>";
            while($row = mysqli_fetch_assoc($zap)) {
                echo "<li>".$row["imie"]." ".$row["nazwisko"]."</li>";
                };
            echo "</ol>";

            mysqli_close($conn);
        ?>
    </section>
    <footer>
        <p>Projekt witryny: 00000000000</p>
    </footer>
</body>
</html>