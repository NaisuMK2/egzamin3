<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="numeric" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Wyświetl liczbę w odwrotnej kolejności"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];
                
                while($liczba > 0){
                    echo $liczba%10;
                    $liczba = floor($liczba/10);
                }
            }
        ?>
    </body>
</html>