<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post" id="polacz">
            <label for="cz1">Tekst 1 </label>
            <input type="text" id="cz1" name="cz1"></input>
            <br>
            <label for="cz2">Tekst 2 </label>
            <input type="text" id="cz2" name="cz2"></input>
            <br>
            <input type="submit" value="Połącz"></input>

        </form>

        <div id="wynik"></div>

    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $cz1 = $_POST["cz1"];
                $cz2 = $_POST["cz2"];

                echo $cz1 . $cz2;
            }
        ?>
    </body>
</html>