<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Pokaż liczby parzyste począwszy od 11, mniejsze od podanej liczby"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                if  ($liczba <= 11){
                    echo "Podaj liczbę większą od 11!";
                }

                $i = 11;

                while ($i <= $liczba){
                    if ($i%2 == 0){
                        echo $i." ";
                    }
                    $i++;
                }
            }
        ?>
    </body>
</html>