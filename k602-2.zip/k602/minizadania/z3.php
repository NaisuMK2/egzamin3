<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>

    <body>
        <form method="post">
                <label for="tekst">Liczba: </label>
                <input type="text" id="tekst" name="tekst"></input>
                <br>
                <input type="submit" value="Należy do przedziału?A"></input>
        </form>

        <?php

            if ($_SERVER["REQUEST_METHOD"] == "POST"){
                $tekst = $_POST['tekst'];

                if ($tekst >= 10 && $tekst < 31){
                    echo "Liczba $tekst należy do przedziału <10,31)";
                } else{
                    echo "liczba $tekst nie należy do przedziału <10,31)";
                };
            };
        ?>
    </body>
</html>