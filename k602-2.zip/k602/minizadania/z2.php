<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post" id="polacz">
            <label for="dzielnia">Dzielna </label>
            <input type="number" id="dzielnia" name="dzielnia"></input>
            <br>
            <label for="dzielnik">Dzielnik </label>
            <input type="number" id="dzielnik" name="dzielnik"></input>
            <br>
            <input type="submit" value="Dzielenie"></input>

        </form>

        <div id="wynik"></div>

    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $dzielnia = $_POST["dzielnia"];
                $dzielnik = $_POST["dzielnik"];

                if ($dzielnia == 0 || $dzielnik == 0){
                    echo "Liczba niemoże być równa 0.";
                } else {
                    $wynik = $dzielnia / $dzielnik;
                    round($wynik, 3);
                    echo "Wynikiem dzielenia jest: " . $wynik;
                }
            }
        ?>

        <!-- <script>
            let dzielnia = document.getElementById("dzielnia").value;
            let dzielnik = document.getElementById("dzielnik").value;

            if (dzielnia == 0 || dzielnik == 0){
                    document.getElementById("wynik").innerHTML = "Liczba niemoże być równa 0.";
                } else {
                    let wynik = (dzielnia / dzielnik);
                    document.getElementById("wynik").innerHTML = ("Wynikiem dzielenia jest: " + wynik);
                }

        </script> -->
    </body>
</html>