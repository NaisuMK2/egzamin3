<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST"){

        if (isset($_POST['sport'])){
            $sport = $_POST['sport'];
            echo $sport;
        };
    }
        ?>