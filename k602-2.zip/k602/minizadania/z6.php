<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Zgadnij jaka to liczba"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];
                if ($liczba < 10){
                    echo "Twoja liczba jest mniejsza niż 10";
                } else if ($liczba == 10){
                    echo "Twoja liczba to 10";
                } else {
                    echo "Twoja liczba jest większa niż 10";
                }
            }
        ?>
    </body>
</html>