<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <style>
            #kwadrat {
            height: 5000px;
            width: 5000px;
}
</style>
    </head>
        <form method="post">
            <input type="radio" id="green" name="kolor" value="green">Zielony</input>
            <br>
            <input type="radio" id="red" name="kolor" value="red">Czerwony</input>
            <br>
            
            <input type="submit" value="Pokaż kwadrat"></input>

        </form>

    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $kolor = $_POST["kolor"];
                echo '<div id="kwadrat" style="background-color:'.$kolor.'"></div>';
            }
        ?>
    </body>
</html>