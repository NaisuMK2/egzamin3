<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post" action="z5_wynik.php">
            <select name="sport">
                <option value="Piłka nożna">Piłka nożna</option>
                <option value="Piłka ręczna">Piłka ręczna</option>
                <option value="Koszykówka">Koszykówka</option>
                <option value="Siatkówka">Siatkówka</option>
            </select>
            <input type="submit" value="Wybór ulubionego sport"></input>
        </form>

    <body>
    </body>
</html>