<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Podaj liczbę"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                $suma = 1;

                while ($suma != $liczba){
                    $potega = pow($suma,2);
                    if ($potega < $liczba){
                        echo $potega." ";
                    }
                    $suma++;
                }

            }
        ?>
    </body>
</html>