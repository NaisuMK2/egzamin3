<html>
    <head>
        <meta charset="utf-8" />
        <title>Sesje</title>
    </head>

    <?php
        session_start ();
        if (isset($_SESSION['zalogowany '])){
        echo "Jesteś zalogowany jako: ".$_SESSION['zalogowany'];
        };
        session_destroy ();
    ?>

    <body>
        <a href="logowanie.php">Powrót do strony logowania</a>
    </body>
</html>

