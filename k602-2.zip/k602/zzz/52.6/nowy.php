<html>
    <head>
        <meta charset="utf-8" />
        <title>Sesje</title>
    </head>

    <body>
        <b>Zarejestruj się na stronie</b>

        <form method="POST">
            <br>Login: <input type="text" name="login">
            <br>Hasło: <input type="password" name="haslo">
            <br><br><input type="submit" value="Zarejestruj się">
        </form>

        <?php

        session_start () ;

        if (isset($_POST['login']) && isset($_POST['haslo'])){
        $login=$_POST['login'];
        $haslo=$_POST['haslo'] ;
        $_SESSION['rejestracja']=1;

        $conn=mysqli_connect ('localhost','root','', 'baza1') ;
        $z1=mysqli_query($conn,"INSERT INTO uzytkownik
        VALUES ('$login', '$haslo')");

        header ('location: logowanie.php');
        exit();
        }

    ?>

    </body>
</html>


