<?php
    session_start ();
        if (!isset($_SESSION['liczba']))
        {
        $_SESSION['liczba'] = 0;
        }
        else
        {
        $_SESSION['liczba']=$_SESSION['liczba']+1;
        echo 'Odwiedziłeś nas: '.$_SESSION['liczba'].' razy';
        }
?>

