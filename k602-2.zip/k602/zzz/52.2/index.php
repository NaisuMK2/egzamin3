<html>
    <head>
        <meta charset="utf-8" />
        <title>Ciasteczka</title>

        <?php
            if (!isset($_COOKIE['moje'])){
            setcookie('moje','ciacho1') ;
            $info="Ciasteczko nie jest ustawione";
            }

            else{
            $info="Ciasteczko jest ustawione, a jego wartością jest
            ".$_COOKIE['moje'];
            }

            echo $info;
        ?>

    </head>
</html>

