<?php
    session_start ();
        echo "Identyfikator sesji: ".session_id();
    session_destroy () ;
?>

