<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Organizer</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <section id="baner1">
        <h2>MÓJ ORGANIZER</h2>
    </section>
    <section id="baner1">
        <form method="POST">
            Wpis wydarzenia: <input type="text" name="wydarzenie" id="wydarzenie"></input>
            <input type="submit" value="ZAPISZ">
        </form>

        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){
                $conn = new mysqli('localhost','root','','egzamin6');

                $wydarzenie = $_POST['wydarzenie'];


                mysqli_query($conn,"UPDATE zadania SET wpis = '".$wydarzenie."' WHERE dataZadania LIKE '2020-08-07';");
                $conn->close();
            }
        ?>

    </section>
    <section id="baner2">
        <img src="logo2.png" alt="Mój organizer">
    </section>

    <section>
        <?php
                $conn = new mysqli('localhost','root','','egzamin6');

                $zap = mysqli_query($conn,"SELECT dataZadania, miesiąc, wpis FROM zadania WHERE miesiąc = 'sierpień';");

                while($row = mysqli_fetch_assoc($zap)){
                    echo "<div id='dane_dnia'>
                    <h6>".$row["dataZadania"].", ".$row["miesiąc"]."</h6>
                    <p>".$row["wpis"]."</p>
                    </div>";
                }

                $conn->close();
        ?>
    </section>

    <footer>
    <?php
                $conn = new mysqli('localhost','root','','egzamin6');

                $zap = mysqli_query($conn,"SELECT miesiąc, rok FROM zadania WHERE dataZadania LIKE '2020-08-01';");

                if($row = mysqli_fetch_assoc($zap)){
                    echo "<h1>miesiąc: ".$row["miesiąc"].", rok: ".$row["rok"]."</h1>";
                }

                $conn->close();
        ?>
        <p>Stronę wykonał: 00000000000</p>
    </footer>
</body>
</html>