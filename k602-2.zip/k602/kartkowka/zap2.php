<?php
    $conn = new mysqli("localhost", "root", "", "place2");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    };

    mysqli_query($conn, "INSERT INTO premia(stanowisko, premia_procent) VALUES ('konserwator', 0.18);");

    $conn->close(); 
?>