<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <input type="button" value="Zapytanie 1" id="zap1">
        <input type="button" value="Zapytanie 2" id="zap2">

        <script>
            document.getElementById("zap1").addEventListener("click",function(){
                fetch("zap1.php",{method: "POST"})
            })

            document.getElementById("zap2").addEventListener("click",function(){
                fetch("zap2.php",{method: "POST"})
            })
        </script>
</body>
</html>