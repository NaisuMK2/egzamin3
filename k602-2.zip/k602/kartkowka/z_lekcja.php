<?php
                $conn = new mysqli("localhost", "root", "", "place2");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                };

                $zap1 = mysqli_query($conn, "SELECT imie, Nazwisko, datazatrudnienia FROM pracownicy WHERE datazatrudnienia > '2000-1-1' AND Nazwisko LIKE 'K%';");

                while($row = mysqli_fetch_assoc($zap1)) {
                echo $row["imie"]." ".$row["Nazwisko"]." ".$row["datazatrudnienia"]."<br>";
                };

                echo "<hr>";

                $zap2 = mysqli_query($conn, "SELECT imie, Nazwisko, stanowisko, plec FROM pracownicy INNER JOIN premia USING (IDStanowiska) WHERE stanowisko LIKE 'Informatyk' AND plec LIKE 'M';");

                while($row = mysqli_fetch_assoc($zap2)) {
                echo $row["imie"]." ".$row["Nazwisko"]." "."<br>";
                };

                $conn->close(); 
?>