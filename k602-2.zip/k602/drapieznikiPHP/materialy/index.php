<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Odżywianie zwierząt</title>
</head>
<body>
    <h3>Wybierz styl życia:</h3>
    <form method="post">
        <select name="zwierze">
            <option value="1">Drapieżniki</option>
            <option value="2">Roślinożerne</option>
            <option value="3">Padlinożerne</option>
            <option value="4">Wszystkżerne</option>
            <input type="submit" value="Zobacz">
        </select>
    </form>

    <?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $conn = mysqli_connect("localhost","root","","zwierzeta");
        $zwierze = $_POST["zwierze"];
        
        $lista = array("Drapieżniki","Roślinożerne","Padlinożerne","Wszystkżerne");

        echo "<h3>".$lista[$zwierze-1]."</h3>";

        echo "<ol>";
        $zap = mysqli_query($conn,"SELECT id, gatunek, wystepowanie FROM zwierzeta WHERE Odzywianie_id = ".$zwierze.";");
        while($row = mysqli_fetch_assoc($zap)){
            echo "<li value='".$row['id']."'> ".$row['gatunek'].", ".$row['wystepowanie']."</li>";
        }
        echo "</ol>";
    }
    ?>
</body>
</html>