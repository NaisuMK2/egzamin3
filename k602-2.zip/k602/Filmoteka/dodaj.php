<?php
$conn = mysqli_connect('localhost','root','','egzamin'); 

$tytul = $_POST['tytul'];

$gatunek = $_POST['gatunek'];

$rok = $_POST['rok'];

$ocena = $_POST['ocena'];

$wynik = mysqli_query($conn, "INSERT INTO filmy VALUES('','.$gatunek.','6','.$tytul.','.$rok.','.$ocena.')");
echo "Film ".$tytul." zostal dodany do bazy";
mysqli_close($conn);
?>