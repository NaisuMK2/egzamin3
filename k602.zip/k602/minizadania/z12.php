<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Losuj aż wylosujesz liczbe"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                if ($liczba > 100 || $liczba <= 0 || $liczba == null){
                    echo 'Liczba musi być w zakresie od 1 do 100';
                    exit;
                }

                $los = 'Kiszone ogórki';

                while ($liczba != $los){
                    $los = rand(1,100);
                    echo $los . ' ';
                }

            }
        ?>
    </body>
</html>