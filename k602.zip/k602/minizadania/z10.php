<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
        Podstawa <input type="number" id="podstawa" name="podstawa"></input>
            <br>
        Wykladnik <input type="number" id="wykladnik" name="wykladnik"></input>
            <br>
            <input type="submit" value="Oblicz potęgowanie"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $podstawa = $_POST["podstawa"];
                $wykladnik = $_POST["wykladnik"];

                $wynik = pow($podstawa, $wykladnik);

                echo 'Wynikiem potęgowania jest: '.$wynik;
            }
        ?>
    </body>
</html>