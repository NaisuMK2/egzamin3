<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <style>
            body {
                background-color: red;
            }
        </style>
    </head>
    <body>
        <h1>Kolor tła: red</h2>
    </body>
</html>