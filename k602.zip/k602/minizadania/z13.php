<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <style>
            #kwadrat {
            height: 50px;
            width: 50px;
            margin-bottom: 10px;
            margin-right: 10px;
            float: left;
            }
</style>
    </head>
    <body>
        <form method="post">
            Podaj ilość kwadratów <input type="number" id="liczba" name="liczba"></input>
            <br>
            
            <input type="submit" value="Pokaż kwadraty"></input>

        </form>

        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                while ($liczba != 0){
                    echo '<div id="kwadrat" style="background-color: rgb('.rand(0,255).','.rand(0,255).','.rand(0,255).')"></div>'.'<div id="spacer"></div>';
                    $liczba--;
                }
            }
        ?>
    </body>
</html>