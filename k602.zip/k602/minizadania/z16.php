<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Zamień na liczbę binarną"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                $wynik = '';
                while ($liczba != 0){
                    if ($liczba%2 == 0){
                        $wynik .= '0';
                        $liczba = $liczba / 2;
                    } else{
                        $wynik .= '1';
                        $liczba = ($liczba -1) / 2;
                    }
                }

                echo strrev($wynik);
            }
        ?>
    </body>
</html>