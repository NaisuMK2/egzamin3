<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post" action="z4php.php">
            <label for="plec">Mężczyzna </label>
            <input type="radio" id="Mężczyzna" name="plec" value="Mężczyzna"></input>
            <br>
            <label for="plec">Kobieta </label>
            <input type="radio" id="Kobieta" name="plec" value="Kobieta"></input>
            <br>
            <label for="plec">Płeć bez znaczenia </label>
            <input type="radio" id="plec" name="plec" value="Płeć bez znaczenia"></input>
            <br>
            
            <input type="submit" value="Sprawdź płeć"></input>

        </form>

        <div id="wynik"></div>

    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $plec = $_POST["plec"];
                echo $plec;
            }
        ?>
    </body>
</html>