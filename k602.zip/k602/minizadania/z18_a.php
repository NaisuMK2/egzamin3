<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <style>
            body {
                background-color: aqua;
            }
        </style>
    </head>
    <body>
        <h1>Kolor tła: aqua</h2>
    </body>
</html>