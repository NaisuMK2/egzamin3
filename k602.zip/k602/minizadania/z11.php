<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            <input type="number" id="liczba" name="liczba"></input>
            <br>
            <input type="submit" value="Oblicz silnie"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $liczba = $_POST["liczba"];

                $wynik = 1;
                while ($liczba > 1){
                    $wynik *= $liczba;
                    $liczba--;
                }

                echo $wynik;

            }
        ?>
    </body>
</html>