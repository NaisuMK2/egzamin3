<html lang="pl">
    <head>
        <meta charset="UTF-8">
    </head>
        <form method="post">
            Szerokość <input type="number" id="szerokosc" name="szerokosc"></input>
            <br>
            Wysokość <input type="number" id="wysokosc" name="wysokosc"></input>
            <br>
            <input type="submit" value="Pokaż prostokąt narysowany ze znaków gwiazdki"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $szerokosc = $_POST["szerokosc"];
                $wysokosc = $_POST["wysokosc"];

                $i = 1;
                while ($i <= $wysokosc){
                    echo "<br>*";
                    $x = 1;
                    while ($x < $szerokosc){
                        echo " *";
                        $x++;
                    }
                    
                    $i++;
                };

            }
        ?>
    </body>
</html>