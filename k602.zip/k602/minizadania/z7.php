<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <style>
            table, td, th {  
            border: 2px solid black;
            text-align: left;
            }
            th, td {
            padding: 15px;
}
        </style>
    </head>
        <form method="post">
            <input type="number" id="kolumny" name="kolumny"></input>
            <br>
            <input type="number" id="wiersze" name="wiersze"></input>
            <br>
            <input type="submit" value="Pokaż tabelę"></input>

        </form>
    <body>
        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST"){

                $kolumny = $_POST["kolumny"];
                $wiersze = $_POST["wiersze"];

                $i = 1;

                echo "<table>";

                while ($i <= $wiersze){
                    echo "<tr>";

                    $x = 1;
                    while ($x <= $kolumny){
                        echo "<td></td>";
                        $x++;
                    }
                    
                    echo "</tr>";
                    $i++;
                };

                echo "</table>";
            }
        ?>
    </body>
</html>