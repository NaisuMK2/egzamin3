<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Kalkulator</title>
</head>
<body>
    <form method="post">
        Wczytaj liczbę: <input type="number" id="liczba" name="liczba"></input>
        <input type="submit" value="Potęga&sup2"></input>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $liczba = $_POST["liczba"];

        $wynik = pow($liczba,2);

        echo "Potęga liczby ".$liczba." wynosi: ".$wynik;
    }
    ?>
</body>
</html>