<?php
                $conn = new mysqli("localhost", "root", "", "cukierki");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                };

                $zap1 = mysqli_query($conn, "SELECT NazwaPudelka, Cena FROM pudelka WHERE Cena > 10");

                while($row = mysqli_fetch_assoc($zap1)) {
                echo $row["NazwaPudelka"]." ".$row["Cena"]."<br>";
                };

                echo "<hr>";

                $zap2 = mysqli_query($conn, "SELECT NazwaPudelka, Ilosc FROM pudelka INNER JOIN zawartosc_pudelko USING (IDPudelka);");

                while($row = mysqli_fetch_assoc($zap2)) {
                echo $row["NazwaPudelka"]." ".$row["Ilosc"]."<br>";
                };

                $conn->close(); 
?>