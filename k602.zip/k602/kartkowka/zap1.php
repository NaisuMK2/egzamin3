<?php
    $conn = new mysqli("localhost", "root", "", "place2");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    };

    mysqli_query($conn, "UPDATE pracownicy SET pensjazasadnicza = pensjazasadnicza * 1.15;");

    $conn->close(); 
?>