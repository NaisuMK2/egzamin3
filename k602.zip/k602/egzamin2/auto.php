<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <title>Komis Samochodowy</title>
        <link rel="stylesheet" href="auto.css">
    </head>

    <body>
        <section id="baner">
            <h1>SAMOCHODY</h2>
        </section>

        <section id="lewy">
            <h2>Wykaz samochodów</h2>

            <ul style="list-style-type: disc">
            <?php
                $conn = new mysqli("localhost","root","","komis",);

                $zap1 = mysqli_query($conn, "SELECT id, marka, model FROM samochody");

                while($row = mysqli_fetch_assoc($zap1)) {
                echo "<li>".$row["id"]." ".$row["marka"]." ".$row["model"]."</li>";
                };
            ?>
            </ul>

            <h2>Zamówienia</h2>

            <ul>
            <?php
                $conn = new mysqli("localhost","root","","komis",);

                $zap2 = mysqli_query($conn, "SELECT samochody_id, klient FROM zamowienia");

                while($row = mysqli_fetch_assoc($zap2)) {
                echo "<li>".$row["samochody_id"]." ".$row["klient"]."</li>";
                };

            ?>
            </ul>

        </section>
        <section id="prawy">
            <h2>Pełne dane: Fiat</h2>
            <?php
                $conn = new mysqli("localhost","root","","komis",);

                $zap3 = mysqli_query($conn, "SELECT * FROM samochody WHERE marka LIKE 'Fiat'");

                while($row = mysqli_fetch_assoc($zap3)) {
                echo $row["id"]." / ".$row["marka"]." / ".$row["model"]." / ".$row["rocznik"]." / ".$row["kolor"]." / ".$row["stan"]."<br>";
                };
            ?>
        </section>
        <footer>
            <table>
                <tr>
                    <th><a href="kwerendy.txt">Kwerendy<a></th>
                    <th>Autor: 00000000000</th>
                    <th><img src="auto.png" alt="komis samochodowy"></th>
                </tr>
            </table>
        <footer>
    </body>
</html>